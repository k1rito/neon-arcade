const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
const state={best:JSON.parse(localStorage.getItem("neonArcadeBest")||"{}")};
function saveBest(k,v){if((state.best[k]||0)<v){state.best[k]=v;localStorage.setItem("neonArcadeBest",JSON.stringify(state.best))}}
function show(id){$$(".view").forEach(x=>x.classList.remove("active"));$("#"+id).classList.add("active");}
$$("[data-view]").forEach(b=>b.addEventListener("click",()=>show(b.dataset.view)));
$$(".game-card").forEach(b=>b.addEventListener("click",()=>startGame(b.dataset.game)));
$("#backGames").addEventListener("click",()=>show("games"));

const games={
rush:{name:"Neon Rush",eyebrow:"DODGE & COLLECT"},
reaction:{name:"Reaction",eyebrow:"SPEED TEST"},
clicker:{name:"10 Second Click",eyebrow:"CLICK CHALLENGE"},
dodger:{name:"Star Dodger",eyebrow:"SURVIVAL"},
memory:{name:"Memory Grid",eyebrow:"BRAIN CHALLENGE"}
};

function startGame(id){
 show("play"); $("#gameTitle").textContent=games[id].name;$("#gameEyebrow").textContent=games[id].eyebrow;$("#best").textContent=state.best[id]||0;
 const area=$("#gameArea"); area.innerHTML=""; window.cancelAnimationFrame(window.currentRAF||0);
 if(id==="rush")rush(area,id); if(id==="reaction")reaction(area,id); if(id==="clicker")clicker(area,id); if(id==="dodger")dodger(area,id); if(id==="memory")memory(area,id);
}
function controls(area,html){const d=document.createElement("div");d.className="game-controls";d.innerHTML=html;area.appendChild(d);return d}

function rush(area,id){
 const c=document.createElement("canvas");c.width=800;c.height=450;c.className="game-canvas";area.appendChild(c);const x=c.getContext("2d");
 const msg=document.createElement("div");msg.className="game-msg";msg.textContent="Press Start, then use WASD or arrow keys.";area.appendChild(msg);
 const ctl=controls(area,'<button>Start</button><button>Pause</button>');
 const [start,pause]=ctl.children;let p,obs,coins,score,running=false,paused=false,last=0,sp=0,cs=0,keys={};
 const reset=()=>{p={x:400,y:225,r:15};obs=[];coins=[];score=0;sp=0;cs=0};
 const spawn=()=>{let side=Math.floor(Math.random()*4),x1,y1,vx,vy,s=180+Math.min(230,score);if(side===0){x1=-25;y1=Math.random()*450;vx=s;vy=(225-y1)*.22}else if(side===1){x1=825;y1=Math.random()*450;vx=-s;vy=(225-y1)*.22}else if(side===2){x1=Math.random()*800;y1=-25;vx=(400-x1)*.22;vy=s}else{x1=Math.random()*800;y1=475;vx=(400-x1)*.22;vy=-s}obs.push({x:x1,y:y1,r:12+Math.random()*9,vx,vy})};
 function end(){running=false;let sc=Math.floor(score);saveBest(id,sc);$("#best").textContent=state.best[id];msg.textContent=`Game over — ${sc} points.`}
 function draw(){x.clearRect(0,0,800,450);x.strokeStyle="#202838";for(let i=0;i<800;i+=40){x.beginPath();x.moveTo(i,0);x.lineTo(i,450);x.stroke()}for(let i=0;i<450;i+=40){x.beginPath();x.moveTo(0,i);x.lineTo(800,i);x.stroke()}x.fillStyle="#67e8f9";x.beginPath();x.arc(p.x,p.y,p.r,0,7);x.fill();x.fillStyle="#ffd43b";coins.forEach(q=>{x.beginPath();x.arc(q.x,q.y,8,0,7);x.fill()});x.fillStyle="#fb7185";obs.forEach(o=>{x.beginPath();x.arc(o.x,o.y,o.r,0,7);x.fill()})}
 function loop(t){if(!running)return;let dt=Math.min(.035,(t-last)/1000);last=t;if(!paused){let dx=(keys.ArrowRight||keys.d?1:0)-(keys.ArrowLeft||keys.a?1:0),dy=(keys.ArrowDown||keys.s?1:0)-(keys.ArrowUp||keys.w?1:0),l=Math.hypot(dx,dy)||1;p.x=Math.max(18,Math.min(782,p.x+dx/l*260*dt));p.y=Math.max(18,Math.min(432,p.y+dy/l*260*dt));score+=dt*10;sp+=dt;cs+=dt;if(sp>.75){sp=0;spawn()}if(cs>1.2){cs=0;coins.push({x:25+Math.random()*750,y:25+Math.random()*400})}obs.forEach(o=>{o.x+=o.vx*dt;o.y+=o.vy*dt});obs=obs.filter(o=>o.x>-60&&o.x<860&&o.y>-60&&o.y<510);for(const o of obs)if(Math.hypot(o.x-p.x,o.y-p.y)<o.r+p.r)return end();coins=coins.filter(q=>{if(Math.hypot(q.x-p.x,q.y-p.y)<p.r+8){score+=50;return false}return true})}draw();window.currentRAF=requestAnimationFrame(loop)}
 start.onclick=()=>{reset();running=true;paused=false;msg.textContent="Survive as long as possible!";last=performance.now();draw();window.currentRAF=requestAnimationFrame(loop)};pause.onclick=()=>{if(running)paused=!paused};
 const kd=e=>{keys[e.key]=true;if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(e.key))e.preventDefault()};const ku=e=>keys[e.key]=false;window.addEventListener("keydown",kd);window.addEventListener("keyup",ku);area._cleanup=()=>{window.removeEventListener("keydown",kd);window.removeEventListener("keyup",ku);cancelAnimationFrame(window.currentRAF||0)};reset();draw();
}

function reaction(area,id){
 const b=document.createElement("button");b.className="big-button";b.textContent="PRESS START";area.appendChild(b);const msg=document.createElement("div");msg.className="game-msg";area.appendChild(msg);let timer,started=false,go=false,startTime;
 b.onclick=()=>{if(!started){started=true;go=false;b.className="big-button wait";b.textContent="WAIT...";msg.textContent="Don't click yet.";timer=setTimeout(()=>{go=true;startTime=performance.now();b.className="big-button ready";b.textContent="CLICK!";msg.textContent="GO!";},1000+Math.random()*2500)}else if(go){let ms=Math.round(performance.now()-startTime);saveBest(id,1000-ms);$("#best").textContent=state.best[id]||0;b.textContent=ms+" ms";msg.textContent=ms<250?"Lightning fast!":"Try again to beat it.";started=false;go=false}else{clearTimeout(timer);b.className="big-button";b.textContent="TOO EARLY";msg.textContent="Wait for green.";started=false}};
}

function clicker(area,id){
 const t=document.createElement("div");t.className="timer";t.textContent="10.0";area.appendChild(t);const b=document.createElement("button");b.className="click-target";b.textContent="START";area.appendChild(b);const msg=document.createElement("div");msg.className="game-msg";area.appendChild(msg);let count=0,end=0,running=false,raf;
 b.onclick=()=>{if(!running){running=true;count=0;end=performance.now()+10000;b.textContent="CLICK!";msg.textContent="Go!";const tick=()=>{let left=Math.max(0,end-performance.now());t.textContent=(left/1000).toFixed(1);if(left<=0){running=false;b.textContent=count+" CLICKS";saveBest(id,count);$("#best").textContent=state.best[id];msg.textContent="Time! Try to beat your score.";return}raf=requestAnimationFrame(tick)};tick()}else count++};
}

function dodger(area,id){
 const c=document.createElement("canvas");c.width=800;c.height=450;c.className="game-canvas";area.appendChild(c);const x=c.getContext("2d"),msg=document.createElement("div");msg.className="game-msg";msg.textContent="Move with arrows or A/D.";area.appendChild(msg);const ctl=controls(area,"<button>Start</button>");const start=ctl.children[0];let p,rocks,run,last,spawn,score,keys={};
 function reset(){p={x:400,y:390};rocks=[];run=false;score=0;spawn=0}
 function loop(t){if(!run)return;let dt=Math.min(.04,(t-last)/1000);last=t;let dx=(keys.ArrowRight||keys.d?1:0)-(keys.ArrowLeft||keys.a?1:0);p.x=Math.max(20,Math.min(780,p.x+dx*330*dt));spawn+=dt;if(spawn>.35){spawn=0;rocks.push({x:20+Math.random()*760,y:-20,r:8+Math.random()*15,s:150+score*.8})}rocks.forEach(o=>o.y+=o.s*dt);rocks=rocks.filter(o=>o.y<480);score+=dt*10;for(const o of rocks)if(Math.hypot(o.x-p.x,o.y-p.y)<o.r+13){run=false;saveBest(id,Math.floor(score));$("#best").textContent=state.best[id];msg.textContent="You survived "+Math.floor(score)+" points. Try again!";}x.clearRect(0,0,800,450);x.fillStyle="#67e8f9";x.beginPath();x.moveTo(p.x,p.y-15);x.lineTo(p.x-13,p.y+12);x.lineTo(p.x+13,p.y+12);x.fill();x.fillStyle="#fb7185";rocks.forEach(o=>{x.beginPath();x.arc(o.x,o.y,o.r,0,7);x.fill()});if(run)window.currentRAF=requestAnimationFrame(loop)}
 const kd=e=>{keys[e.key]=true;if(["ArrowLeft","ArrowRight"].includes(e.key))e.preventDefault()},ku=e=>keys[e.key]=false;window.addEventListener("keydown",kd);window.addEventListener("keyup",ku);start.onclick=()=>{reset();run=true;last=performance.now();msg.textContent="Survive!";window.currentRAF=requestAnimationFrame(loop)};reset();
}

function memory(area,id){
 const info=document.createElement("div");info.className="game-msg";info.textContent="Watch the highlighted squares, then repeat them.";area.appendChild(info);
 const grid=document.createElement("div");grid.className="memory-grid";area.appendChild(grid);let cells=[];for(let i=0;i<9;i++){let c=document.createElement("button");c.className="memory-cell";c.setAttribute("aria-label","Grid cell "+(i+1));grid.appendChild(c);cells.push(c)}
 const ctl=controls(area,"<button>Start</button>");let seq=[],input=0,level=0,playing=false;
 function showSeq(){playing=true;input=0;cells.forEach(c=>c.disabled=true);seq.forEach((n,i)=>setTimeout(()=>{cells[n].classList.add("lit");setTimeout(()=>cells[n].classList.remove("lit"),280)},i*420));setTimeout(()=>{playing=false;cells.forEach(c=>c.disabled=false)},seq.length*420+300)}
 function next(){level++;seq.push(Math.floor(Math.random()*9));info.textContent="Level "+level+" — watch!";showSeq()}
 ctl.children[0].onclick=()=>{level=0;seq=[];next()};
 cells.forEach((c,i)=>c.onclick=()=>{if(playing)return;if(i!==seq[input]){info.textContent="Wrong! You reached level "+level+".";saveBest(id,level-1);$("#best").textContent=state.best[id]||0;cells.forEach(q=>q.disabled=true);return}c.classList.add("correct");setTimeout(()=>c.classList.remove("correct"),160);input++;if(input===seq.length)setTimeout(next,400)});
}
