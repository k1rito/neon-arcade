# Neon Arcade

A browser game hub containing:
- Neon Rush
- Reaction
- 10 Second Click
- Star Dodger
- Memory Grid

## Run
Open `index.html` in a browser.

## Customize
Edit `style.css` for the design and `script.js` to add/change games.

No server or external libraries are required.
